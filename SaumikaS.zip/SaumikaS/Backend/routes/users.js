const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../model/Users'); // Ensure correct model path
const router = express.Router();

// JWT Secret Key
const jwtSecret = 'supersecretkey';

// POST /login route
router.post('/login', async (req, res) => {
    const { username, password } = req.body; // Use username instead of email

    try {
        // Find the user by username
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(400).json({ msg: 'Invalid username or password' });
        }

        // Compare passwords
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ msg: 'Invalid username or password' });
        }

        // Generate a JWT token
        const token = jwt.sign({ userId: user._id }, jwtSecret, { expiresIn: '1h' });

        // Update loginStatus to 'online' after successful login
        user.loginStatus = 'online';
        await user.save();

        // Send token and user data back to client
        res.json({ token, username: user.username, loginStatus: user.loginStatus });
    } catch (error) {
        console.error(error.message);
        res.status(500).send('Server error');
    }
});

module.exports = router;

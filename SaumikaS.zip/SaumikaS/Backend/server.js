const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/authRoutes');
const postRoutes = require('./routes/postRoutes');
const replyRoutes = require('./routes/replyRoutes');
const searchRoutes = require('./routes/searchRoutes');
const UserModel = require('./model/Users');
const Review = require('./model/reviews');
const { MONGODB_URI } = require('./config/db');

const app = express();
const PORT = process.env.PORT || 5001;

// Connect to MongoDB
mongoose.connect(MONGODB_URI || "mongodb://127.0.0.1:27017/users", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => console.error('Failed to connect to MongoDB', err));

// Middleware
app.use(cors());
app.use(express.json());

// Root route to prevent "Cannot GET /" error
app.get('/', (req, res) => {
    res.send('API is running...');
});

// User authentication routes
app.use('/api/auth', authRoutes);

// Post, reply, and search routes
app.use('/api/posts', postRoutes);
app.use('/api/replies', replyRoutes);
app.use('/api', searchRoutes);  // Search routes

// User routes
app.post("/createUser", (req, res) => {
    const { firstname, lastname, username, password, profilePicture } = req.body;
    const loginStatus = "offline"; // Example default value

    UserModel.create({ firstname, lastname, username, password, profilePicture, loginStatus })
        .then(user => res.json(user))
        .catch(err => res.status(400).json({ error: err.message }));
});

app.get("/users", (req, res) => {
    UserModel.find()
        .then(users => res.json(users))
        .catch(err => res.status(400).json({ error: err.message }));
});

app.get("/user/:id", (req, res) => {
    UserModel.findById(req.params.id)
        .then(user => user ? res.json(user) : res.status(404).json({ message: "User not found" }))
        .catch(err => res.status(400).json({ error: err.message }));
});

app.put("/updateUser/:id", (req, res) => {
    const { firstname, lastname, username, password, profilePicture, loginStatus } = req.body;

    UserModel.findByIdAndUpdate(req.params.id, { firstname, lastname, username, password, profilePicture, loginStatus }, { new: true })
        .then(updatedUser => updatedUser ? res.json(updatedUser) : res.status(404).json({ message: "User not found" }))
        .catch(err => res.status(400).json({ error: err.message }));
});

app.delete("/deleteUser/:id", (req, res) => {
    UserModel.findByIdAndDelete(req.params.id)
        .then(deletedUser => deletedUser ? res.json({ message: "User deleted successfully" }) : res.status(404).json({ message: "User not found" }))
        .catch(err => res.status(400).json({ error: err.message }));
});

// Review routes
app.post('/reviews', async (req, res) => {
    try {
        const { reviewText, rating, userId } = req.body;

        const user = await UserModel.findById(userId);
        if (!user) return res.status(404).json({ error: 'User not found' });

        const newReview = new Review({ reviewText, rating, userId });
        await newReview.save();
        res.status(201).json(newReview);
    } catch (error) {
        res.status(500).json({ error: 'Error saving the review' });
    }
});

app.get('/reviews/:id', async (req, res) => {
    try {
        const reviews = await Review.find({ userId: req.params.id }).populate('userId', 'firstname lastname profilePicture'); // Populate user info
        res.json(reviews);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching reviews' });
    }
});

app.put('/reviews/:id', async (req, res) => {
    try {
        const { reviewText, rating } = req.body;
        const review = await Review.findById(req.params.id);
        if (!review) return res.status(404).json({ error: 'Review not found' });

        review.reviewText = reviewText;
        review.rating = rating;
        await review.save();
        res.json(review);
    } catch (error) {
        res.status(500).json({ error: 'Error updating the review' });
    }
});

app.delete('/reviews/:id', async (req, res) => {
    try {
        const review = await Review.findByIdAndDelete(req.params.id);
        if (!review) return res.status(404).json({ error: 'Review not found' });

        res.json({ message: 'Review deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Error deleting the review' });
    }
});

app.get('/reviews', async (req, res) => {
    try {
        const reviews = await Review.find()
            .populate('userId', 'firstname lastname profilePicture')
            .exec();

        const reviewsWithUserInfo = reviews.map(review => ({
            reviewText: review.reviewText,
            rating: review.rating,
            publishedDate: review.publishedDate,
            username: `${review.userId.firstname} ${review.userId.lastname}`,
            profilePicture: review.userId.profilePicture
        }));

        res.json(reviewsWithUserInfo);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching reviews' });
    }
});

// Start the server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

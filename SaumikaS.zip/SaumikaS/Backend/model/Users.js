const mongoose = require('mongoose');
const bcrypt = require('bcryptjs'); // Make sure bcrypt is installed using `npm install bcryptjs`

const userSchema = new mongoose.Schema({
    firstname: { type: String, required: true },
    lastname: { type: String, required: true },
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    profilePicture: { type: String }
});

// Add the isValidPassword method
userSchema.methods.isValidPassword = async function(password) {
    // Compare the plain text password with the hashed password stored in the database
    return await bcrypt.compare(password, this.password);
};

// Pre-save hook to hash the password before saving
userSchema.pre('save', async function(next) {
    if (this.isModified('password') || this.isNew) {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
    }
    next();
});

// Correctly define and export the User model
const User = mongoose.model('User', userSchema);

module.exports = User;

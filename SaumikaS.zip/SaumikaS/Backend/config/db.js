// backend/config/db.js
module.exports = {
    MONGODB_URI: 'mongodb://127.0.0.1:27017/forumDB',
};

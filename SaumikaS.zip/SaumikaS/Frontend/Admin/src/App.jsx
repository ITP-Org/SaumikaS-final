import NavBar from './navBar.jsx';
import '../css/App.css';
import { Route, Routes, Navigate } from 'react-router-dom';
import Home from './Home.jsx';
import Login from './Login.jsx';
import Users from './Users.jsx';
import Content from './Content.jsx';
import Inquiry from './Inquiry.jsx';
import Reviews from './Reviews.jsx';

import logo from '../src/assets/logo2.png';

function App() {
  const isAuthenticated = !!localStorage.getItem('token'); 

  return (
    <>
    <img src={logo} alt="logo" className="logo" />

      <NavBar />
      <div className="Admin-container">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/home" element={isAuthenticated ? <Home /> : <Navigate to="/" />} />
          <Route path="/Users" element={isAuthenticated ? <Users /> : <Navigate to="/" />} />
          <Route path="/Content" element={isAuthenticated ? <Content /> : <Navigate to="/" />} />
          <Route path="/Inquiry" element={isAuthenticated ? <Inquiry /> : <Navigate to="/" />} />
          <Route path="/Reviews" element={isAuthenticated ? <Reviews /> : <Navigate to="/" />} />
        </Routes>
      </div>
    </>
  );
}

export default App;

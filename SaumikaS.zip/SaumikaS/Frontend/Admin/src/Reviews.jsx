import Title from '../Components/Title.jsx'; // Adjust the path to where your Title component is located


function Reviews() {
    return(
        <div>
        <Title title="Reviews" />
        {/* Other components and content */}
    </div>
    );
}

export default Reviews;
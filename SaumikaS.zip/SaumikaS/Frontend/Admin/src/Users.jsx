import React, { useState, useEffect } from 'react';
import Title from '../Components/Title.jsx'; 
import '../css/Users.css';
import { IoPersonAddOutline } from "react-icons/io5";

function Users() {
    const [users, setUsers] = useState([]); // Store the list of users
    const [newUser, setNewUser] = useState({ firstname: '', lastname: '', username: '', password: '', profilePicture: '' }); // New schema fields
    const [editingUser, setEditingUser] = useState(null); // Track which user is being edited
    const [loading, setLoading] = useState(true); // Loading state
    const [error, setError] = useState(''); // Error message state
    const [searchQuery, setSearchQuery] = useState(''); // Store the search query
    const [formErrors, setFormErrors] = useState({}); // Validation error state

    // Fetch all users when the component mounts
    useEffect(() => {
        fetchUsers();
    }, []);

    // Fetch users from the backend
    const fetchUsers = async () => {
        try {
            setLoading(true);
            const response = await fetch('http://localhost:3001/users');

            if (!response.ok) {
                throw new Error('Failed to fetch users');
            }
            const data = await response.json();
            setUsers(data);
        } catch (error) {
            console.error('Error fetching users:', error);
            setError('Failed to fetch users');
        } finally {
            setLoading(false); // Stop loading
        }
    };

    // Validate user input
    const validateForm = (user) => {
        const errors = {};
        if (!user.firstname.trim()) {
            errors.firstname = 'First name is required';
        }
        if (!user.lastname.trim()) {
            errors.lastname = 'Last name is required';
        }
        if (!user.username.trim()) {
            errors.username = 'Username is required';
        }
        if (!user.password.trim()) {
            errors.password = 'Password is required';
        } else if (user.password.length < 6) {
            errors.password = 'Password must be at least 6 characters';
        }
        if (!user.profilePicture.trim()) {
            errors.profilePicture = 'Profile picture is required';
        }
        return errors;
    };

    // Create a new user
    const handleCreateUser = async () => {
        const errors = validateForm(newUser);
        setFormErrors(errors);
        if (Object.keys(errors).length > 0) return; // Stop if there are validation errors

        try {
            const response = await fetch('http://localhost:3001/createUser', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newUser),
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to create user');
            }
            const data = await response.json();
            setUsers([...users, data]); 
            setNewUser({ firstname: '', lastname: '', username: '', password: '', profilePicture: '' });
        } catch (error) {
            console.error('Error creating user:', error);
            setError('Failed to create user');
        }
    };

    // Update an existing user
    const handleUpdateUser = async (id) => {
        const errors = validateForm(editingUser);
        setFormErrors(errors);
        if (Object.keys(errors).length > 0) return; 

        try {
            const response = await fetch(`http://localhost:3001/updateUser/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(editingUser),
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to update user');
            }
            const updatedUser = await response.json();
            setUsers(users.map(user => user._id === id ? updatedUser : user)); // Update the user in the state
            setEditingUser(null); // Clear the editing state
        } catch (error) {
            console.error('Error updating user:', error);
            setError('Failed to update user');
        }
    };

    // Delete a user
    const handleDeleteUser = async (id) => {
        try {
            const response = await fetch(`http://localhost:3001/deleteUser/${id}`, {
                method: 'DELETE',
            });
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to delete user');
            }
            setUsers(users.filter(user => user._id !== id)); // Remove user from the state
        } catch (error) {
            console.error('Error deleting user:', error);
            setError('Failed to delete user');
        }
    };

    // Filter users based on the search query
    const filteredUsers = users.filter(user => {
        const firstname = user.firstname ? user.firstname.toLowerCase() : '';
        const lastname = user.lastname ? user.lastname.toLowerCase() : '';
        const username = user.username ? user.username.toLowerCase() : '';
        return (
            firstname.includes(searchQuery.toLowerCase()) ||
            lastname.includes(searchQuery.toLowerCase()) ||
            username.includes(searchQuery.toLowerCase())
        );
    });

    // Generate a CSV report of users
    const handleGenerateReport = () => {
        const csvRows = [
            ['First Name', 'Last Name', 'Username'], // Headers
            ...users.map(user => [user.firstname, user.lastname, user.username]) // Data rows
        ];

        const csvContent = csvRows.map(row => row.join(',')).join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = 'users_report.csv';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="UserM">
            <Title title="User Management" />

            <div className="searchBar">
                <h2>Search User</h2>
                <input
                    type="text"
                    placeholder="Search by name, lastname, or username"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="searchInput"
                />
            </div>

            <div className="addUser">
                <h2>Add User</h2>
                <input
                    type="text"
                    placeholder="First Name"
                    value={newUser.firstname}
                    onChange={(e) => setNewUser({ ...newUser, firstname: e.target.value })}
                />
                {formErrors.firstname && <p style={{ color: 'red' }}>{formErrors.firstname}</p>}
                <input
                    type="text"
                    placeholder="Last Name"
                    value={newUser.lastname}
                    onChange={(e) => setNewUser({ ...newUser, lastname: e.target.value })}
                />
                {formErrors.lastname && <p style={{ color: 'red' }}>{formErrors.lastname}</p>}
                <input
                    type="text"
                    placeholder="Username"
                    value={newUser.username}
                    onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                />
                {formErrors.username && <p style={{ color: 'red' }}>{formErrors.username}</p>}
                <input
                    type="password"
                    placeholder="Password"
                    value={newUser.password}
                    onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                />
                {formErrors.password && <p style={{ color: 'red' }}>{formErrors.password}</p>}
                <input
                    type="text"
                    placeholder="Profile Picture URL"
                    value={newUser.profilePicture}
                    onChange={(e) => setNewUser({ ...newUser, profilePicture: e.target.value })}
                />
                {formErrors.profilePicture && <p style={{ color: 'red' }}>{formErrors.profilePicture}</p>}
                <button style={{ backgroundColor: '#6244a0' }} onClick={handleCreateUser}>
                    <IoPersonAddOutline />
                </button>
            </div>

            <div className="UserMContainer">
                {loading ? (
                    <p>Loading users...</p>
                ) : (
                    <>
                        {error && <p style={{ color: 'red' }}>{error}</p>}

                        <h2>User List</h2>
                        <ul>
                            {filteredUsers.map(user => (
                                <li key={user._id}>
                                    {editingUser && editingUser._id === user._id ? (
                                        <div>
                                            <input
                                                type="text"
                                                value={editingUser.firstname}
                                                onChange={(e) => setEditingUser({ ...editingUser, firstname: e.target.value })}
                                            />
                                            {formErrors.firstname && <p style={{ color: 'red' }}>{formErrors.firstname}</p>}
                                            <input
                                                type="text"
                                                value={editingUser.lastname}
                                                onChange={(e) => setEditingUser({ ...editingUser, lastname: e.target.value })}
                                            />
                                            {formErrors.lastname && <p style={{ color: 'red' }}>{formErrors.lastname}</p>}
                                            <input
                                                type="text"
                                                value={editingUser.username}
                                                onChange={(e) => setEditingUser({ ...editingUser, username: e.target.value })}
                                            />
                                            {formErrors.username && <p style={{ color: 'red' }}>{formErrors.username}</p>}
                                            <input
                                                type="text"
                                                value={editingUser.profilePicture}
                                                onChange={(e) => setEditingUser({ ...editingUser, profilePicture: e.target.value })}
                                            />
                                            {formErrors.profilePicture && <p style={{ color: 'red' }}>{formErrors.profilePicture}</p>}
                                            <button style={{ backgroundColor: '#4CAF50' }} onClick={() => handleUpdateUser(user._id)}>
                                                Update
                                            </button>
                                            <button style={{ backgroundColor: '#f44336' }} onClick={() => setEditingUser(null)}>
                                                Cancel
                                            </button>
                                        </div>
                                    ) : (
                                        <div>
                                            <img src={user.profilePicture} alt="Profile" style={{ width: '50px', borderRadius: '50%' }} />
                                            <p>{user.firstname} {user.lastname} ({user.username})</p>
                                            <button style={{ backgroundColor: '#2196F3' }} onClick={() => setEditingUser(user)}>
                                                Edit
                                            </button>
                                            <button style={{ backgroundColor: '#f44336' }} onClick={() => handleDeleteUser(user._id)}>
                                                Delete
                                            </button>
                                        </div>
                                    )}
                                </li>
                            ))}
                        </ul>

                        <button className="generateReportButton" onClick={handleGenerateReport}>
                            Generate CSV Report
                        </button>
                    </>
                )}
            </div>
        </div>
    );
}

export default Users;

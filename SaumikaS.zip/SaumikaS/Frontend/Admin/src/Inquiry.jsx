import Title from '../Components/Title.jsx'; // Adjust the path to where your Title component is located

function Inquiry() {
    return(
        <div>
        <Title title="Inquiries" />
        {/* Other components and content */}
    </div>
    );
}

export default Inquiry;
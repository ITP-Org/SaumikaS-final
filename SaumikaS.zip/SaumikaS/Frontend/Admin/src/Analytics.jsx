import Title from '../Components/Title.jsx'; // Adjust the path to where your Title component is located


function Analytics() {
    return(
        <div>
        <Title title="Analytics" />
        {/* Other components and content */}
    </div>
    );
}

export default Analytics;
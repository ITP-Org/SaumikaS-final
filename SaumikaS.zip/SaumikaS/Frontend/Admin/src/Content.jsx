import Title from '../Components/Title.jsx'; // Adjust the path to where your Title component is located
function Users() {
    return(
        <div>
            <Title title="Forum Management" />
            <Forum/>
        </div>
    );
}

export default Users;
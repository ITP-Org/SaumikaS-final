import React from 'react';
import Title from '../Components/Title.jsx'; // Adjust the path to where your Title component is located
import '../css/App.css'

function App() {
    return (
        <div>
            <Title title="Welcome Admin!" />
            {/* Other components and content */}
        </div>
    );
}

export default App;

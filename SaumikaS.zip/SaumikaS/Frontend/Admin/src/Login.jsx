import React, { useState } from 'react';
import { FaUser, FaUnlockAlt } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';
import '../css/Login.css';

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const hardcodedEmail = 'lonath@gmail.com';
    const hardcodedPassword = '123';

    const handleSubmit = (e) => {
        e.preventDefault();

        if (email === hardcodedEmail && password === hardcodedPassword) 
        {
            console.log('login successful');
            localStorage.setItem('token', 'fake-jwt-token');
            navigate('/Users');
        } else {
            console.log('login unsuccessful');
            setError('Invalid email or password');
        }
    };

    return (
        <div className="Login-Container">
            <form onSubmit={handleSubmit}>
                <h1>Admin Login</h1>

                <div className="Input-Box">
                    <input 
                        type="text" 
                        placeholder='Email' 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                    <FaUser className='Icon'/>
                </div>

                <div className="Input-Box">
                    <input 
                        type="password" 
                        placeholder='Password' 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <FaUnlockAlt className='Icon'/>
                </div>

                {error && <p className="error-message">{error}</p>}

                <div className="forget-remember">
                    <label><input type="checkbox"/> Remember Me</label>
                    <a href="#">Forget Password</a>
                </div>

                <button className="login-btn" type="submit">Login</button>

                <div className="register-link">
                    <p>Don't have an account? <a href="#">Register</a></p>
                </div>
            </form>
        </div>
    );
}

export default Login;

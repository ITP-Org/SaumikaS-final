
import './App.css'
import HeroBackground from './HeroBackground.jsx'
import Form from './Login-form.jsx';
import ScrollContainer from './ScrollContainer.jsx';

function App() {

  return (
    <>
    <Form/>
    <HeroBackground></HeroBackground>
    </>
  )
}

export default App

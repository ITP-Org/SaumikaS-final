import './Header.css';
import React from 'react';
import Logo from '../assets/logo2.png';
import { Link, useNavigate, useParams } from 'react-router-dom';

function Header() {
    const navigate = useNavigate();  // Hook to programmatically navigate
    const { id } = useParams();  // Get URL parameters

    const handleLoginClick = () => {
        navigate('/login');  // Redirect to the Login component
    };

    const handleRegisterClick = () => {
        navigate('/register');  // Redirect to the Register component
    };

    return (
        <header>
            <div className="Logo">
                <img src={Logo} alt="logo" />
            </div>

            <nav>
                <ul>
                    <li>
                        <Link to={`/${id}`}>
                            <button className="nav-btn">Home</button>
                        </Link>
                    </li>
                    <li>
                        <Link to={`/CourseContent/${id}`}>
                            <button className="nav-btn">Course Content</button>
                        </Link>
                    </li>
                    <li>
                        <Link to={`/Forum/${id}`}>
                            <button className="nav-btn">Forum</button>
                        </Link>
                    </li>
                    <li>
                        <Link to={`/Cart/${id}`}>
                            <button className="nav-btn">Cart</button>
                        </Link>
                    </li>
                </ul>
            </nav>

            <div className="Profile">
                <button className="login-btn" onClick={handleLoginClick}>Login</button>
                <button className="register-btn" onClick={handleRegisterClick}>Register</button>
            </div>
        </header>
    );
}

export default Header;

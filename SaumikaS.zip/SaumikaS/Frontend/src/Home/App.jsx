import './App.css';
import Home from '../HomePage/Home.jsx';
import CourseContent from '../CourseContent/CourseContent.jsx';
import Forum from '../forum/src/components/Forum/PostList.jsx';
import Cart from '../Cart/Cart.jsx';
import LoginForm from '../Login/Login-form.jsx';
import Header from '../Home/Header.jsx';
import Footer from '../Home/Footer.jsx';
import PostList from '../forum/src/components/Forum/PostList.jsx';
import SearchResults from '../forum/src/components/SearchResults.jsx';
import PostDetails from '../forum/src/components/PostDetails.jsx';
import ReportPage from '../forum/src/components/ReportPage.jsx';
import Forum_Admin from '../forum/src/components/Forum_Admin.jsx';
import { BrowserRouter as Router, Routes, Route, useLocation, useParams } from 'react-router-dom';
import Reviews from '../reviews/AllReviewsPage';
import UserReviewsPage from '../reviews/UserReviewsPage';

function ParamsWrapper({ Component }) {
  const params = useParams();
  return <Component params={params} />;
}

function App() {
  const location = useLocation();

  // Check if the current path is for the admin forum or report page
  const showNavBar = location.pathname === '/forum_admin' || location.pathname === '/report';
  const showHeaderFooter = !(location.pathname === '/forum_admin' || location.pathname === '/report');

  return (
    <>
      {showHeaderFooter && <Header />} {/* Conditionally render Header */}
      {showNavBar && <NavBar />} {/* Conditionally render NavBar */}

      <Routes>
        {/* General Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/home/:id" element={<ParamsWrapper Component={Home} />} />
        <Route path="/login" element={<LoginForm />} />
        {/* <Route path="/register" element={<Register />} /> */}

        {/* Course, Forum, and Cart Routes */}
        <Route path="/CourseContent/:id" element={<ParamsWrapper Component={CourseContent} />} />
        <Route path="/Forum/:id" element={<ParamsWrapper Component={Forum} />} />
        <Route path="/Cart/:id" element={<ParamsWrapper Component={Cart} />} />

        {/* Review Routes */}
        <Route path="/reviews/:id" element={<ParamsWrapper Component={Reviews} />} />
        <Route path="/user-reviews/:id" element={<ParamsWrapper Component={UserReviewsPage} />} />

        {/* Forum & Post Routes */}
        <Route path="/postlist" element={<PostList />} />
        <Route path="/search" element={<SearchResults />} />
        <Route path="/posts/:id" element={<ParamsWrapper Component={PostDetails} />} />

        {/* Admin and Report Routes */}
        <Route path="/report" element={<ReportPage />} />
        <Route path="/forum_admin" element={<Forum_Admin />} />
      </Routes>

      {showHeaderFooter && <Footer />} {/* Conditionally render Footer */}
    </>
  );
}

export default App;

import React, { useState } from 'react';
import { FlipWords } from '../components/ui/flip-word';
import './HeroText.css';

const HeroText = () => {
  const [words] = useState(["Chemistry", "With", "Saumika"]);

  return (

    <>
    <div className="hero-text-container">

        <div className='OtherText'>WELCOME TO</div>
            <FlipWords words={words} duration={3000} className="text"></FlipWords>

        
    </div>

    <div className='hero-text-container2'>Ignite Curiosity, Fuel Knowledge</div>
    </>
  );
}

export default HeroText;

import { BackgroundGradientAnimation } from '../components/ui/background-gradient-animation';

function HeroBackground() {
  return (
    <div>
      <BackgroundGradientAnimation>
      </BackgroundGradientAnimation>
    </div>
  );
}

export default HeroBackground;

// import React from 'react';
import { ContainerScroll } from '../components/ui/container-scroll-animation';
import HeroBackground from '../Home/HeroBackground.jsx'

import './Scroll-Clicker.css';

function ScrollContainer() {
    return (
        <>
        <div className="Scroller">
        <div className="Scroll-Title">
            <h1>Visit Us Now 
                On Youtube</h1>
            </div>
            <ContainerScroll className="ContainerScroll"/>
            {/* <HeroBackground className="HeroBackground"/> */}
        </div>
        </>
    );
}

export default ScrollContainer;


import './App.css'
import HeroBackground from './HeroBackground.jsx'
import Form from './Login-form.jsx';

function App() {

  return (
    <>
    <Form/>
    <HeroBackground></HeroBackground>
    </>
  )
}

export default App

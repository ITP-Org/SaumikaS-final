import React, { useState } from 'react';
import './Login.css';
import { FaUser } from "react-icons/fa";
import { FaUnlockAlt } from "react-icons/fa";
import { useNavigate } from 'react-router-dom';  // Import useNavigate

function Form() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState(''); // To store any error messages
    const navigate = useNavigate();  // Initialize the useNavigate hook

    const handleSubmit = async (e) => {
        e.preventDefault();
    
        try {
            const response = await fetch('http://localhost:3001/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password }),
            });
    
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
    
            const data = await response.json();
            if (data.success) {
                sessionStorage.setItem('objectID', data.id);
                sessionStorage.setItem('username', username);
                navigate(`/home/${data.id}`); // Use backticks here
            } else {
                setError("Invalid credentials!");
            }
        } catch (error) {
            console.error("Error during login:", error);
            setError("Server error. Please try again later.");
        }
    };
    
    return (
        <div className="Login-Container">
            <form onSubmit={handleSubmit}>
                <h1>Login</h1>

                {error && <p className="error">{error}</p>} {/* Display any error messages */}

                <div className="Input-Box">
                    <input 
                        type="text" 
                        placeholder='Username' 
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                    <FaUser className='Icon'/>
                </div>

                <div className="Input-Box">
                    <input 
                        type="password" 
                        placeholder='Password' 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <FaUnlockAlt className='Icon'/>
                </div>

                <div className="forget-remember">
                    <label><input type="checkbox"/> Remember Me</label>
                    <a href="#">Forget Password</a>
                </div>

                <button className="login-btn" type="submit">Login</button>

                <div className="register-link">
                    <p>Don't have an account? <a href="#">Register</a></p>
                </div>
            </form>
        </div>
    );
}

export default Form;


import HeroBackground from '../Home/HeroBackground.jsx'
import { useNavigate } from 'react-router-dom';

import ScrollContainer from '../Home/ScrollContainer.jsx';
import Footer from '../Home/Footer.jsx'
import HeroText from '../Home/HeroText.jsx';
import './Home.css'

import { useParams } from 'react-router-dom';

export default function Home() {

    const { id } = useParams(); // Get the objectID from the URL

    const navigate = useNavigate();

    function handleReviewsClick() {
      navigate(`/reviews/${id}`); // Navigate to the Reviews page
    }

    return (
        <>
    <HeroText/>
    <button className="reviews-btn" onClick={handleReviewsClick}> Reviews</button>
    <h1>Hello {id}</h1>
    <HeroBackground className="Background"></HeroBackground>
    <ScrollContainer/>
    <Footer/>
    </>
    );
}
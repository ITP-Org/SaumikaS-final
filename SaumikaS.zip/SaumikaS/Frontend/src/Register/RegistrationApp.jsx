import React from 'react';
import ReactDOM from 'react-dom';
import RegistrationForm from './RegistrationForm';

function Registration() {
  return (
    <div>
      <h1>Welcome to Our Site</h1>
      <RegistrationForm />
    </div>
  );
};

export default Registration;
import HeroBackground from '../Home/HeroBackground.jsx'

export default function Cart() {
    return (
        <>

        <HeroBackground/>
        </>
    );
}
import React from 'react';
import { useParams } from 'react-router-dom';
import Header from '../Home/Header.jsx';
import Footer from '../Home/Footer.jsx';
import Carousel from "./Carousel.jsx";

function AllReviewsPage() {
    const { id } = useParams(); // Extract URL parameters

    return (
        <>
            <Header />
            <Carousel id={id} /> {/* Pass the id to Carousel if needed */}
            <Footer />
        </>
    );
}

export default AllReviewsPage;

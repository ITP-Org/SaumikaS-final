import HeroBackground from '../Home/HeroBackground.jsx'
import SearchBar from './SearchBar';


function CourseContent() 
{
    
        const handleSearch = (query) => {
            // Implement your search logic here
            console.log('Searching for:', query);
            // Example: Call an API, update state, etc.
        };

    return(
        <>
        <div className="App">
            <SearchBar placeholder="Enter keyword..." onSearch={handleSearch} />
        </div>
        <HeroBackground/>
        </>

    );

}

export default CourseContent